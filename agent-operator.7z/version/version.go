/*
 * (c) Copyright IBM Corp. 2021
 * (c) Copyright VC Inc. 2021
 */

package version

var (
	Version   = "snapshot"
	GitCommit = "unspecified"
)
