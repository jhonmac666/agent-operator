/*
 * (c) Copyright IBM Corp. 2021
 * (c) Copyright VC Inc. 2021
 */

package v1

// Hub marks this type as a conversion hub.
func (*VcAgent) Hub() {}
